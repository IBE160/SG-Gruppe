const express = require('express');
const cors = require('cors');
const OpenAI = require('openai');
const axios = require('axios');
const { JSDOM } = require('jsdom');
const path = require('path');

// Load environment variables from .env file
require('dotenv').config({ path: path.resolve(__dirname, '.env') });

const app = express();
// Use the port provided by the environment (like Render), or default to 3001
const PORT = process.env.PORT || 3001; 

app.use(cors());
app.use(express.json({ limit: '10mb' })); 

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Using the efficient GPT-3.5-Turbo model
const MODEL = 'gpt-3.5-turbo'; 

// ✅ FIX: Increased output tokens significantly to ensure the full JSON and analysis text are generated.
const MAX_OUTPUT_TOKENS = 2500; 
// Reduced max input size to 3000 chars to avoid overall token limits
const MAX_INPUT_CHARS = 3000; 

// ---------- helper ----------
function extractJson(content) {
  const start = content.indexOf('{');
  const end = content.lastIndexOf('}');
  if (start === -1 || end === -1) {
      console.error('Failed to find JSON structure in response:', content);
      throw new Error('No JSON found in AI response');
  }
  return JSON.parse(content.slice(start, end + 1));
}

// =========================
// Analyse endpoint
// =========================
app.post('/api/analyze', async (req, res) => {
  // Includes cvText (must be sent from the client)
  const { cvText, coverLetter, jobPosting, keywords, toneStyle, isUrl } = req.body;

  // Apply the new, smaller character limits to all inputs
  const safeCvText = (cvText || '').slice(0, MAX_INPUT_CHARS);
  const safeCoverLetter = (coverLetter || '').slice(0, MAX_INPUT_CHARS);
  let jobPostingText = (jobPosting || '').slice(0, MAX_INPUT_CHARS);

  // --- Job Posting URL Scraping ---
  if (isUrl && jobPosting) {
    try {
      const response = await axios.get(jobPosting, {
        headers: { 'User-Agent': 'Mozilla/5.0' },
      });
      const dom = new JSDOM(response.data);
      // Apply character limit after scraping
      jobPostingText =
        (dom.window.document.body.textContent || '').slice(0, MAX_INPUT_CHARS);
    } catch (e) {
      console.error('Failed to fetch/scrape job posting URL:', e.message);
      return res.status(500).json({ error: 'Failed to fetch job posting from URL.' });
    }
  }

  const prompt = `
Return ONLY raw JSON. No explanations. No markdown.

{
  "applicationAnalysis": "...",
  "jobPostingAnalysis": "...",
  "keywordComparison": { "found": [], "missing": [] },
  "coverLetter": "...",
  "cvImprovements": "...",
  "gapAnalysis": "...",
  "atsOptimization": "..."
}

CV Text:
${safeCvText || '[No CV provided]'}

Draft Application/Cover Letter:
${safeCoverLetter || '[No draft provided]'}

Job Posting:
${jobPostingText}

Keywords:
${keywords || 'None'}

Tone:
${toneStyle || 'Professional'}
`;

  // ---------- attempt 1 ----------
  try {
    const completion = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.6,
      // Use the increased token count here
      max_tokens: MAX_OUTPUT_TOKENS, 
    });

    try {
      // Return the successfully extracted JSON
      return res.json(extractJson(completion.choices[0].message.content));
    } catch {
      // ---------- attempt 2 (automatic fix if JSON extraction failed) ----------
      const retry = await openai.chat.completions.create({
        model: MODEL,
        messages: [
          { role: 'user', content: prompt },
          {
            role: 'system',
            content:
              'The previous JSON was invalid. Return a FIXED and COMPLETE JSON object only.',
          },
        ],
        temperature: 0.3,
        max_tokens: MAX_OUTPUT_TOKENS,
      });

      return res.json(extractJson(retry.choices[0].message.content));
    }
  } catch (err) {
    // Robust Error Logging and Handling
    console.error('--- AI Analysis Error Details ---');
    console.error('Error Status:', err.status);
    console.error('Error Message:', err.message);
    console.error('Error Code:', err.code);
    console.error('---------------------------------');

    if (err.status === 429 || err.code === 'rate_limit_exceeded') {
      return res.status(429).json({
        error: 'Too many requests (429). Please try again shortly.',
      });
    }
    
    if (err.status === 401) {
        return res.status(401).json({
            error: 'Authentication error. Please check your OPENAI_API_KEY environment variable.',
        });
    }

    // Generic 500 error for all other failures
    return res.status(500).json({
      error: 'AI analysis failed (500). Please check server logs for details.',
    });
  }
});

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
