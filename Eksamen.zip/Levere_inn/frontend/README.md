# AI Job Application Improvement Tool

This project is an AI-powered web tool designed to help students improve the quality of their job applications. It provides immediate, actionable feedback, helping users optimize their application documents for both automated screeners and human recruiters, thereby increasing their chances of securing an interview.

For more detailed information about the project, please refer to the [Project Brief](../brief.md).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

### Running the backend

To run the backend server, navigate to the `backend` directory and run:

```
npm start
```

The backend server will start on [http://localhost:3001](http://localhost:3001).

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.
