# AI Job Application Assistant

## Project Overview

This is a full-stack web application designed to assist users in improving their job application materials. The application uses the OpenAI API to analyze a user's CV, cover letter (or draft), and a target job posting. It then provides a detailed analysis, suggestions for improvement, and generates a new, customized cover letter.

**Note:** For the convenience of grading this academic project, the necessary OpenAI API credentials have been hardcoded into the backend server.

---

## Project Structure

The project is organized into two main directories:

-   `/frontend`: A React application that serves as the user interface.
-   `/backend`: A Node.js and Express server that handles the business logic and connection to the OpenAI API.

---

## Getting Started

Follow these steps to get the application running locally.

### Prerequisites

-   **Node.js**: You must have Node.js installed on your system, preferably version 18.x or later. You can download it from [nodejs.org](https://nodejs.org/).

### Step 1: Install Dependencies

1.  Navigate to the **root directory** of the project.
2.  Run the following command in your terminal:

    ```bash
    npm install
    ```

    This single command will install the dependencies for the root project, and will then automatically trigger the installation for both the `/frontend` and `/backend` services.

### Step 2: Run the Application

1.  Make sure you are in the **root directory** of the project.
2.  Run the following command:

    ```bash
    npm start
    ```

This command uses `concurrently` to start both the backend and frontend servers simultaneously.

-   The backend server will start on `http://localhost:3001`.
-   The frontend development server will start on `http://localhost:3000`.
-   Your default web browser should automatically open the application at `http://localhost:3000`.

There is no need to configure any API keys or environment files; the project is ready to run after installation.

---

## A Note on `node_modules`

To keep the submission file size manageable, the `node_modules` directories have been excluded from this project folder. The `npm install` command you run in Step 1 regenerates these directories with all the necessary packages for the project to function correctly.