#!/bin/bash
# This script prepares the project for submission by removing the large node_modules directories.

echo "Cleaning project for submission..."

# Find and remove node_modules directories
# Use -type d to ensure we only target directories
# Use -prune to prevent find from descending into the directories it finds
# Use -exec to run the rm command
find . -name "node_modules" -type d -prune -exec echo "Removing {}..." \; -exec rm -rf {} \;

echo ""
echo "Cleanup complete."
echo "You can now zip this project folder and submit it."
echo "The recipient should follow the instructions in README.md to reinstall the dependencies."
