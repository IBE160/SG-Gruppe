# Backend Server

This Node.js Express server provides AI-powered analysis for job applications using a pre-configured OpenAI API connection.

## Running the Server

This server is started automatically when you run the main application.

To run the entire application (both frontend and backend), navigate to the project's root directory (`eksamen_BMAD`) and run:
```bash
npm start
```
The backend server will start on `http://localhost:3001`. There is no additional setup required.