const path = require('path');
const fetch = require('node-fetch');
const cheerio = require('cheerio');
require('dotenv').config({ path: path.resolve(__dirname, '.env') }); // Use environment variables for credentials

const express = require('express');
const cors = require('cors');
const multer = require('multer');
const pdf = require('pdf-parse');
const fs = require('fs');
const OpenAI = require('openai'); // Import OpenAI SDK

const app = express();
const port = 3001;

// Setup Multer for file storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, 'uploads'))
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
  }
});

const upload = multer({ storage: storage });

app.use(cors());
app.use(express.json());

// Initialize OpenAI with credentials from environment variables.
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  project: process.env.OPENAI_PROJECT_ID,
});
const openaiModel = 'gpt-3.5-turbo';

app.post('/api/upload-cv', upload.single('cv'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('No file uploaded.');
    }

    let dataBuffer = fs.readFileSync(req.file.path);

    pdf(dataBuffer).then(function(data) {
        // cleanup the uploaded file
        fs.unlinkSync(req.file.path);

        // return the extracted text
        res.send({
            text: data.text
        });
    }).catch(function(error){
        console.error(error);
        // handle parsing error
        res.status(500).send({
            error: 'Error parsing PDF file.'
        });
    });
});

app.post('/api/analyze', async (req, res) => {
  const { cv, coverLetter, jobPosting, isUrl } = req.body; // Added isUrl here

  let finalJobPostingContent;

  if (isUrl) {
    try {
      const response = await fetch(jobPosting, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
      });
      const html = await response.text();
      const $ = cheerio.load(html);
      // Basic text extraction - might need refinement based on target websites
      finalJobPostingContent = $('body').text().replace(/\s\s+/g, ' ').trim();
      if (finalJobPostingContent.length < 100) { // Fallback for poor extraction
          // Try to get text from common job posting sections if body is too sparse
          finalJobPostingContent = $('p, li, h1, h2, h3, .job-description, .description').text().replace(/\s\s+/g, ' ').trim();
      }
      if (!finalJobPostingContent) {
        throw new Error('Could not extract meaningful content from the provided URL.');
      }
      // Truncate to prevent exceeding token limits
      if (finalJobPostingContent.length > 15000) {
        console.log(`Truncating job posting content from ${finalJobPostingContent.length} to 15000 characters.`);
        finalJobPostingContent = finalJobPostingContent.substring(0, 15000);
      }
    } catch (urlError) {
      console.error('Error fetching or parsing URL content:', urlError);
      return res.status(400).json({ error: `Failed to retrieve content from URL: ${urlError.message}` });
    }
  } else {
    finalJobPostingContent = jobPosting;
  }


  try {
    // Step 1: Detect the language of the cover letter
    const textForLanguageDetection = coverLetter || finalJobPostingContent;
    const languageDetectionPrompt = `Detect the language of the following text and return only the name of the language (e.g., "English", "Norwegian", "French"). Do not add any other words or punctuation.

Text: "${textForLanguageDetection}"`;

    const languageDetectionCompletion = await openai.chat.completions.create({
      model: openaiModel,
      messages: [{ role: 'user', content: languageDetectionPrompt }],
      temperature: 0,
      max_tokens: 20,
    });

    const detectedLanguage = languageDetectionCompletion.choices[0].message.content.trim() || 'English';
    console.log(`Detected language: ${detectedLanguage}`); // Log the detected language

    // Step 2: Build and execute the main analysis prompt with the detected language
    let cvAnalysisPrompt = '';
    if (cv) {
      cvAnalysisPrompt = `
        ---
        CV / Resume:
        ${cv}
        ---
      `;
    }

    let analysisPrompt;
    if (coverLetter) {
      // Prompt for when a cover letter is provided
      analysisPrompt = `
        You are an AI Job Application Assistant.
        **PRIMARY RULE: Your entire response must be in ${detectedLanguage}.**
        All string values in the final JSON output MUST be in ${detectedLanguage}.

        Analyze the provided CV, draft application/cover letter, and the job posting.
        The 'initialFeedback' field should be a concise, one-sentence critique of the user's original draft.
        The 'applicationAnalysis' should be a thorough analysis of the user's provided draft, cross-referencing the CV.

        Generate a detailed analysis in the following structured JSON format:
        {
          "initialFeedback": "A concise, one-sentence critique.",
          "applicationAnalysis": "A thorough analysis of the provided application text (min. 100-150 words).",
          "jobPostingAnalysis": "A detailed analysis of the job posting (min. 100-150 words).",
          "keywordComparison": { "found": ["keywords"], "missing": ["keywords"] },
          "cvImprovements": "Specific, actionable suggestions to improve the original application text (min. 100 words).",
          "gapAnalysis": "Detailed analysis of missing qualifications or skills based on the CV and job posting (min. 100-150 words).",
          "atsOptimization": "Bulleted list of keywords and formatting suggestions for ATS optimization."
        }

        ${cvAnalysisPrompt}
        ---
        Draft Application / Cover Letter:
        ${coverLetter}
        ---
        Job Posting:
        ${finalJobPostingContent}
        ---
      `;
    } else {
      // Prompt for when NO cover letter is provided
      analysisPrompt = `
        You are an AI Job Application Assistant.
        **PRIMARY RULE: Your entire response must be in ${detectedLanguage}.**
        All string values in the final JSON output MUST be in ${detectedLanguage}.

        The user has not provided a draft. Your primary task is to generate a new cover letter from scratch based *only* on the provided CV and job posting.
        The 'initialFeedback' field should state that no draft was provided (e.g., 'No draft was provided, so I have created a new cover letter from scratch...').
        The 'applicationAnalysis' should be a general analysis based on the job posting and CV, highlighting the key requirements and desired candidate profile.

        Generate a detailed analysis in the following structured JSON format:
        {
          "initialFeedback": "A concise statement indicating that no draft was provided.",
          "applicationAnalysis": "A general analysis of the job posting's key requirements and the candidate's CV (min. 100-150 words).",
          "jobPostingAnalysis": "A detailed analysis of the job posting (min. 100-150 words).",
          "keywordComparison": { "found": ["keywords"], "missing": ["keywords"] },
          "cvImprovements": "General advice on what a strong cover letter for this job should contain, tailored to the CV (min. 100 words).",
          "gapAnalysis": "A general gap analysis based on the CV and job posting (min. 100-150 words).",
          "atsOptimization": "Bulleted list of keywords and formatting suggestions for ATS optimization."
        }

        ${cvAnalysisPrompt}
        ---
        Draft Application / Cover Letter:
        Not provided. Generate from scratch based on the job posting and CV.
        ---
        Job Posting:
        ${finalJobPostingContent}
        ---
      `;
    }

    // --- Step 3: Execute the first analysis-only call ---
    const analysisCompletion = await openai.chat.completions.create({
      model: openaiModel,
      messages: [{ role: 'user', content: analysisPrompt }],
      response_format: { type: "json_object" }, // Request JSON output
      temperature: 0.7,
      max_tokens: 2500, 
    });

    const analysisResponseContent = analysisCompletion.choices[0].message.content;
    
    try {
      // --- Step 4: Parse the analysis and generate the dedicated cover letter ---
      const analysisResult = JSON.parse(analysisResponseContent);

      // Now, create a new, dedicated prompt for generating the cover letter
      const coverLetterPrompt = `
        You are an expert cover letter writer. Your entire response must be in ${detectedLanguage}.
        Based on the provided CV, job posting, and the following analysis, write a new, complete, and professional cover letter.
        The cover letter should be approximately 400-600 words long and consist of 3-4 well-structured paragraphs.
        It must be ready for immediate use. Do not add any other commentary, formatting, or JSON structure. Just return the raw text of the letter.

        ${cvAnalysisPrompt}
        ---
        Job Posting:
        ${finalJobPostingContent}
        ---
        Candidate and Job Analysis:
        ${JSON.stringify({ 
          gapAnalysis: analysisResult.gapAnalysis, 
          cvImprovements: analysisResult.cvImprovements,
          keywordComparison: analysisResult.keywordComparison
        })}
        ---
        ${coverLetter ? `Original Draft (for reference, but create a new, improved version):
        ${coverLetter}` : ''}
        ---
      `;

      const coverLetterCompletion = await openai.chat.completions.create({
        model: openaiModel,
        messages: [{ role: 'user', content: coverLetterPrompt }],
        temperature: 0.8,
        max_tokens: 1500, // Ample tokens for a long cover letter
      });

      const generatedCoverLetter = coverLetterCompletion.choices[0].message.content.trim();

      // --- Step 5: Combine the results and send the final response ---
      analysisResult.coverLetter = generatedCoverLetter;
      analysisResult.detectedLanguage = detectedLanguage; // Include detected language
      
      res.json(analysisResult);

    } catch (parseError) {
      console.error('Error parsing JSON from OpenAI:', parseError);
      console.error('Invalid JSON response from OpenAI. The response was not valid JSON. Cannot log the full response for privacy reasons.');
      res.status(500).json({ error: 'Failed to parse analysis from AI model. Invalid JSON received.' });
    }

  } catch (error) {
    console.error('--- Full Error Object in /api/analyze ---', error);
    if (error instanceof OpenAI.APIError) {
      console.error('OpenAI API Error Status:', error.status);
      console.error('OpenAI API Error Type:', error.type);
      console.error('OpenAI API Error Code:', error.code);
      console.error('OpenAI API Error Param:', error.param);
      if (error.status === 401) {
        return res.status(401).json({ error: 'The OpenAI API key is invalid or has been revoked. Please check your .env file.' });
      } else if (error.status === 429) {
        return res.status(429).json({ error: 'OpenAI API rate limit or quota reached. You may need to add billing details to your OpenAI account.' });
      } else if (error.code === 'model_not_found') {
        return res.status(400).json({ error: 'The OpenAI model was not found or is inaccessible.' });
      }
    }
    // Send a more informative error message to the client
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
    res.status(500).json({ error: `An unexpected error occurred during analysis. Details: ${errorMessage}` });
  }
});

app.post('/api/regenerate-cover-letter', async (req, res) => {
  const { cv, jobPosting, analysis, detectedLanguage } = req.body;

  try {
    const cvAnalysisPrompt = cv ? `---
      CV / Resume:
      ${cv}
      ---` : '';

    const coverLetterPrompt = `
      You are an expert cover letter writer. A previous version was generated for the user.
      **PRIMARY RULE: Your entire response must be in ${detectedLanguage || 'English'}.**
      Your task is to write a **new and distinct** version of the cover letter. It should have a different tone, structure, or focus while still being highly professional and relevant.
      Base the new letter on the provided CV, job posting, and the previous analysis.
      The cover letter should be approximately 400-600 words long and consist of 3-4 well-structured paragraphs.
      It must be ready for immediate use. Do not add any other commentary, formatting, or JSON structure. Just return the raw text of the letter.

      ${cvAnalysisPrompt}
      ---
      Job Posting:
      ${jobPosting}
      ---
      Candidate and Job Analysis (from previous step):
      ${JSON.stringify(analysis)}
      ---
    `;

    const coverLetterCompletion = await openai.chat.completions.create({
      model: openaiModel,
      messages: [{ role: 'user', content: coverLetterPrompt }],
      temperature: 0.85, // Slightly higher temperature for more variation
      max_tokens: 1500,
    });

    const generatedCoverLetter = coverLetterCompletion.choices[0].message.content.trim();
    
    res.json({ coverLetter: generatedCoverLetter });

  } catch (error) {
    console.error('--- Full Error Object in /api/regenerate-cover-letter ---', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
    res.status(500).json({ error: `Failed to regenerate cover letter. Details: ${errorMessage}` });
  }
});

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});
