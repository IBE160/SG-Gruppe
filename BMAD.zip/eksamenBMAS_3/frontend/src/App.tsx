import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import './App.css';
import * as pdfjsLib from 'pdfjs-dist';
import { createWorker } from 'tesseract.js';

// Setup for PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `/pdf.worker.min.mjs`;

interface Message {
  sender: 'user' | 'ai';
  text: string;
  isJson?: boolean;
}

type ConversationStage =
  | 'AWAITING_CV'
  | 'AWAITING_CV_CONFIRMATION'
  | 'AWAITING_COVER_LETTER'
  | 'AWAITING_SHORT_DRAFT_CONFIRMATION'
  | 'AWAITING_JOB_POSTING'
  | 'ANALYZING'
  | 'DISPLAYING_RESULTS'
  | 'ERROR';

function App() {
  const [stage, setStage] = useState<ConversationStage>('AWAITING_CV');
  const [messages, setMessages] = useState<Message[]>([]);
  const [userInput, setUserInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('Thinking...');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [jobPostingUrlInput, setJobPostingUrlInput] = useState('');
  const [analysisData, setAnalysisData] = useState<any>(null); // Store analysis data

  const coverLetterRef = useRef('');
  const jobPostingRef = useRef('');
  const cvRef = useRef('');
  const detectedLanguageRef = useRef('English'); // Add ref for detected language
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMessages([{ sender: 'ai', text: "Hello! I'm your AI Job Application Assistant. Please upload your CV as a PDF or paste the text below. If you don't have one, just press enter." }]);
    setStage('AWAITING_CV');
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const addMessage = (sender: 'user' | 'ai', text: string, isJson: boolean = false) => {
    setMessages(prev => [...prev, { sender, text, isJson }]);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      if (file.type !== 'application/pdf') {
        addMessage('ai', 'Error: Only PDF files are accepted. Please upload a valid PDF.');
        setSelectedFile(null);
        if (event.target) event.target.value = '';
        return;
      }
      setSelectedFile(file);
    }
  };

  const processCvFile = async (file: File): Promise<string> => {
    setLoadingMessage('Reading your PDF...');
    const fileReader = new FileReader();

    return new Promise((resolve, reject) => {
      fileReader.onload = async (e) => {
        try {
          if (!e.target?.result) {
            return reject(new Error('Failed to read file.'));
          }
          const typedArray = new Uint8Array(e.target.result as ArrayBuffer);
          const pdf = await pdfjsLib.getDocument(typedArray).promise;
          let textContent = '';

          setLoadingMessage(`Found ${pdf.numPages} page(s). Extracting text...`);

          for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const text = await page.getTextContent();
            textContent += text.items.map(s => (s as any).str).join(' ');
          }

          if (textContent.trim()) {
            resolve(textContent);
          } else {
            setLoadingMessage('No text found. Starting OCR... This might take a minute.');
            const worker = await createWorker('eng');
            
            let ocrText = '';
            for (let i = 1; i <= pdf.numPages; i++) {
              setLoadingMessage(`Performing OCR on page ${i} of ${pdf.numPages}...`);
              const page = await pdf.getPage(i);
              const viewport = page.getViewport({ scale: 2 });
              const canvas = document.createElement('canvas');
              const context = canvas.getContext('2d')!;
              canvas.height = viewport.height;
              canvas.width = viewport.width;

              await page.render({ canvasContext: context, viewport: viewport, canvas: canvas }).promise;
              const { data: { text } } = await worker.recognize(canvas);
              ocrText += text;
            }
            await worker.terminate();
            resolve(ocrText);
          }
        } catch (error) {
          reject(error);
        }
      };
      fileReader.onerror = () => reject(new Error('Error reading file.'));
      fileReader.readAsArrayBuffer(file);
    });
  };

  const handleSendMessage = async () => {
    const currentUserInput = userInput;
    const currentFile = selectedFile;

    if (currentUserInput) addMessage('user', currentUserInput);
    else if (currentFile) addMessage('user', `Uploaded ${currentFile.name}`);
    else addMessage('user', '(No input provided)');

    setUserInput('');
    setSelectedFile(null);
    setLoading(true);

    try {
      switch (stage) {
        case 'AWAITING_CV':
          if (currentFile) {
            try {
              const extractedText = await processCvFile(currentFile);
              if (!extractedText.trim()) {
                throw new Error('Could not extract any text from the PDF, even after OCR.');
              }
              cvRef.current = extractedText;
              addMessage('ai', `Successfully processed your CV. Are you sure you want to continue? yes/no`);
              setStage('AWAITING_CV_CONFIRMATION');
            } catch (error: any) {
              addMessage('ai', `Error processing PDF: ${error.message || 'An unknown error occurred.'}`);
              setStage('AWAITING_CV');
            }
          } else {
            cvRef.current = currentUserInput;
            addMessage('ai', 'Are you sure you want to continue with the text you provided? yes/no');
            setStage('AWAITING_CV_CONFIRMATION');
          }
          break;

        case 'AWAITING_CV_CONFIRMATION':
          const confirmation = currentUserInput.toLowerCase().trim();
          if (confirmation === 'yes') {
            addMessage('ai', 'CV confirmed. Please paste your cover letter or application text now. Press enter if you don\'t have one to proceed.');
            setStage('AWAITING_COVER_LETTER');
          } else if (confirmation === 'no') {
            addMessage('ai', 'Please paste your CV again, or press enter to skip.');
            cvRef.current = '';
            setStage('AWAITING_CV');
          } else {
            addMessage('ai', 'Invalid input. Please answer with "yes" or "no".');
            // Keep the stage as AWAITING_CV_CONFIRMATION to re-ask the same question
            setStage('AWAITING_CV_CONFIRMATION');
          }
          break;

        case 'AWAITING_COVER_LETTER':
          if (!currentUserInput.trim()) {
            coverLetterRef.current = '';
            addMessage('ai', 'Cover letter skipped. Now, please paste the job application details or description, or provide a URL to the job posting.');
            setStage('AWAITING_JOB_POSTING');
          } else if (currentUserInput.split(' ').filter(word => word).length < 20) {
            addMessage('ai', "Your cover letter seems a bit short. Would you like me to proceed based on this draft? (yes/no)");
            coverLetterRef.current = currentUserInput;
            setStage('AWAITING_SHORT_DRAFT_CONFIRMATION');
          } else {
            coverLetterRef.current = currentUserInput;
            addMessage('ai', 'Great! Now, please paste the job application details or description.');
            setStage('AWAITING_JOB_POSTING');
          }
          break;

        case 'AWAITING_SHORT_DRAFT_CONFIRMATION':
          if (currentUserInput.toLowerCase().trim() === 'yes') {
            addMessage('ai', 'Perfect! I will expand on your draft. Now, please paste the job application details or description, or provide a URL to the job posting.');
            setStage('AWAITING_JOB_POSTING');
          } else {
            addMessage('ai', 'No problem. Please provide a more detailed draft of your cover letter.');
            setStage('AWAITING_COVER_LETTER');
          }
          break;

        case 'AWAITING_JOB_POSTING':
          let jobPostingSource: string;
          let isJobPostingUrl: boolean;

          if (jobPostingUrlInput.trim()) {
            jobPostingSource = jobPostingUrlInput.trim();
            isJobPostingUrl = true;
            addMessage('user', `Job posting URL: ${jobPostingSource}`);
          } else if (currentUserInput.trim()) {
            jobPostingSource = currentUserInput.trim();
            isJobPostingUrl = false;
          } else {
            addMessage('ai', 'The job application details (text or URL) cannot be empty. Please provide either.');
            setLoading(false);
            break;
          }
          
          jobPostingRef.current = jobPostingSource; // Store either URL or text
          
          setLoadingMessage("Analyzing your documents... This may take a moment...");
          setStage('ANALYZING');
          
          const response = await axios.post('http://localhost:3001/api/analyze', {
            cv: cvRef.current,
            coverLetter: coverLetterRef.current,
            jobPosting: jobPostingSource, // Send the URL or text
            isUrl: isJobPostingUrl // Indicate if it's a URL
          }, { timeout: 60000 });

          if (response.data.initialFeedback) {
            addMessage('ai', `A quick note on your draft: ${response.data.initialFeedback}`);
          }
          addMessage('ai', "Analysis complete! Here's your improved, customized cover letter:");
          addMessage('ai', response.data.coverLetter);

          const newAnalysisData = { ...response.data };
          detectedLanguageRef.current = newAnalysisData.detectedLanguage || 'English';
          delete newAnalysisData.coverLetter;
          delete newAnalysisData.initialFeedback;
          delete newAnalysisData.detectedLanguage;
          
          setAnalysisData(newAnalysisData); // Save for regeneration
          addMessage('ai', "I have also prepared a detailed analysis. Please select an option to view the details.");
          addMessage('ai', JSON.stringify(newAnalysisData, null, 2), true);
          
          setStage('DISPLAYING_RESULTS');
          break;
      }
    } catch (error: any) {
      console.error('Error in conversation flow:', error);
      const errorMessage = error.response?.data?.error || 'An unexpected error occurred. Please try again or start over.';
      addMessage('ai', `Error: ${errorMessage}`);
      setStage('ERROR');
    }

    setLoading(false);
    setLoadingMessage('Thinking...');
  };

  const analysisOptions = [
    'Application Text Analysis', 'Improvement Suggestions', 'Gap Analysis', 'ATS Optimization', 'Keyword Comparison', 'Generate New Cover Letter'
  ];

  const handleAnalysisOption = (option: string) => {
    addMessage('user', option);
    const storedAnalysisText = messages.find(m => m.isJson)?.text;
    if (storedAnalysisText) {
      try {
        const storedAnalysis = JSON.parse(storedAnalysisText);
        const keyMap: { [key: string]: string } = {
          'application text analysis': 'applicationAnalysis',
          'improvement suggestions': 'cvImprovements',
          'gap analysis': 'gapAnalysis',
          'ats optimization': 'atsOptimization'
        };
        const key = keyMap[option.toLowerCase()];

        if (key && storedAnalysis[key]) {
          addMessage('ai', `**${option}:**\n${storedAnalysis[key]}`);
        } else if (option.toLowerCase().includes('keyword comparison')) {
          addMessage('ai', `**Keyword Comparison:**\n- Found: ${storedAnalysis.keywordComparison.found.join(', ')}\n- Missing: ${storedAnalysis.keywordComparison.missing.join(', ')}`);
        } else {
          addMessage('ai', "I'm sorry, I couldn't find that analysis.");
        }
      } catch (error) {
        addMessage('ai', "Something went wrong while retrieving the analysis data.");
      }
    } else {
      addMessage('ai', "I can't find the analysis data. You might need to start over.");
    }
  };

  const handleGenerateNewCoverLetter = async () => {
    addMessage('user', 'Generate New Cover Letter');
    setLoading(true);
    setLoadingMessage('Generating a new version...');

    try {
      const response = await axios.post('http://localhost:3001/api/regenerate-cover-letter', {
        cv: cvRef.current,
        jobPosting: jobPostingRef.current,
        analysis: analysisData,
        detectedLanguage: detectedLanguageRef.current, // Pass the language
      });
      addMessage('ai', "Here's another version of your cover letter:");
      addMessage('ai', response.data.coverLetter);
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to generate a new cover letter.';
      addMessage('ai', `Error: ${errorMessage}`);
    }

    setLoading(false);
    setLoadingMessage('Thinking...');
  };
  
  const handleStartAgain = () => {
    setMessages([{ sender: 'ai', text: "Hello! I'm your AI Job Application Assistant. Please upload your CV as a PDF or paste the text below. If you don't have one, just press enter." }]);
    setStage('AWAITING_CV');
    setUserInput('');
    setLoading(false);
    coverLetterRef.current = '';
    jobPostingRef.current = '';
    cvRef.current = '';
    setSelectedFile(null);
    setJobPostingUrlInput(''); // Reset job posting URL input
    setAnalysisData(null); // Clear analysis data
    detectedLanguageRef.current = 'English'; // Reset language
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>AI Job Application Assistant</h1>
        <button onClick={handleStartAgain} className="start-again-button">Start Over</button>
      </header>
      <main className="chat-container">
        <div className="message-list">
          {messages.map((msg, index) => (
            !msg.isJson && (
              <div key={index} className={`message ${msg.sender}`}>
                <p className="pre-wrap">{msg.text}</p>
              </div>
            )
          ))}
          {loading && <div className="message ai"><p>{loadingMessage}</p></div>}
          <div ref={chatEndRef} />
        </div>
        <div className="input-area">
          {stage === 'DISPLAYING_RESULTS' ? (
            <div className="analysis-options">
              {analysisOptions.map((option) => (
                <button 
                  key={option} 
                  onClick={() => {
                    if (option === 'Generate New Cover Letter') {
                      handleGenerateNewCoverLetter();
                    } else {
                      handleAnalysisOption(option);
                    }
                  }} 
                  className="analysis-button"
                  disabled={loading}
                >
                  {option}
                </button>
              ))}
            </div>
          ) : (
            <>
              {stage === 'AWAITING_CV' && (
                <div className="file-input-container">
                  <input type="file" id="cv-upload" accept=".pdf" onChange={handleFileChange} className="file-input" />
                  <label htmlFor="cv-upload" className="file-input-label">
                    {selectedFile ? selectedFile.name : 'Upload CV (PDF)'}
                  </label>
                </div>
              )}

              {stage === 'AWAITING_JOB_POSTING' ? (
                <>
                  <input
                    type="text"
                    className="input-url"
                    placeholder="Or paste job posting URL here..."
                    value={jobPostingUrlInput}
                    onChange={(e) => {
                      setJobPostingUrlInput(e.target.value);
                      if (e.target.value.trim()) {
                        setUserInput(''); // Clear text input if URL is being entered
                      }
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey && jobPostingUrlInput.trim()) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    disabled={loading}
                  />
                  <textarea
                    className="input-textarea"
                    placeholder="Paste job application details or description here and press enter..."
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    disabled={loading || jobPostingUrlInput.trim().length > 0} // Disable if URL is being used
                  />
                </>
              ) : (
                <textarea
                  className="input-textarea"
                  placeholder={
                    stage === 'AWAITING_CV' ? 'Or paste your CV here and press enter...' :
                    'Send a message...'
                  }
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  disabled={loading || !['AWAITING_CV', 'AWAITING_CV_CONFIRMATION', 'AWAITING_COVER_LETTER', 'AWAITING_SHORT_DRAFT_CONFIRMATION'].includes(stage)}
                />
              )}
              <button 
                onClick={handleSendMessage} 
                disabled={loading || (stage === 'AWAITING_CV' && !userInput && !selectedFile) || (stage === 'AWAITING_JOB_POSTING' && !userInput.trim() && !jobPostingUrlInput.trim())} 
                className="send-button"
              >
                Send
              </button>
            </>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;