# User Story: Interactive Job Application Assistant

**ID:** 01
**Title:** Transform the Application into a Conversational AI Assistant
**As a:** Job Seeker
**I want:** To be guided through the process of tailoring my resume and cover letter by an interactive, conversational assistant.
**So that:** I can feel more confident, less overwhelmed, and create a higher-quality, more personalized application by collaborating with the AI.

---

### Description

The current tool requires users to input all information (resume, job description, keywords, tone) at once and receive a single, comprehensive output.

This user story refactors the user experience from a static form into a dynamic, chat-based interface. The AI assistant will guide the user through the process step-by-step, making the interaction feel more like a collaborative session with a career coach. This will involve asking for information sequentially, presenting the generated content for feedback, and allowing for iterative refinement.

### Acceptance Criteria

1.  **Conversational UI:** The main interface is replaced with a chat window (similar to ChatGPT or Gemini). The old form-based input is removed.
2.  **Guided Interaction Flow:**
    - On starting a new session, the assistant greets the user and asks them to paste their resume.
    - After the user provides the resume, the assistant confirms receipt and then asks for the job description.
    - The assistant can optionally ask for keywords and tone, or infer them.
3.  **Iterative Cover Letter Generation:**
    - After receiving the necessary information, the assistant performs the backend analysis.
    - It first presents the generated **Cover Letter** in the chat.
    - The user can provide feedback in plain text (e.g., "make it sound more enthusiastic," "highlight my project management skills").
    - The assistant uses this feedback to generate and present a revised cover letter.
4.  **On-Demand Analysis:**
    - The other analysis sections (Resume Analysis, CV Improvements, Gap Analysis, etc.) are not shown by default.
    - The assistant can offer these insights to the user (e.g., "Would you like me to analyze your resume for weaknesses?"), or the user can ask for them directly ("show me the gap analysis").
5.  **State Management:** The conversation maintains the context of the user's resume, job description, and the latest analysis results throughout the session.
6.  **"Start Over" Functionality:** A button or command exists to clear the session and start a new conversation.

---
### Notes for Development Team

-   **Frontend Focus:** This is primarily a frontend task. The existing backend `/api/analyze` endpoint is robust and can likely be used as-is. The frontend will need to manage the conversational state.
-   **Prompt Engineering:** To handle user feedback for cover letter refinement, we may need a new backend endpoint or to update the existing prompt logic. The new prompt would include the original inputs plus the user's feedback (e.g., `...Here is the first draft of the cover letter: [draft]. The user has requested the following change: [user feedback]. Please generate a new version.`). This is a "Phase 2" consideration if we cannot achieve it on the frontend initially.
-   **UI Components:** We will need to build or integrate a chat message component, a text input bar with a send button, and potentially "thinking" indicators.
